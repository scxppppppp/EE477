Wufei wufei@usc.edu   USCid 6897429283
I have done all the required parts of the Lab3 successfully, including all of the schematic design, layout design, 
passed LVS and DRC results, test and the delay calculation.....
all of the snapshots are include in the lab3 report.