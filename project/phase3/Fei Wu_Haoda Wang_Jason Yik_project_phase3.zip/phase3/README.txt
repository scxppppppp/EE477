Name       email             ID                 Contributions  
Haoda Wang haodawan@usc.edu  USCid  8497309773  extra proposal 
Jason Yik  jyik@usc.edu      USCid  6321385779  extra proposal
Wufei      wufei@usc.edu     USCid  6897429283  all the layout and tests

we have done all the required parts of the project phase3 successfully

including all the components and the integrity of multiplier and divider arbiter and FSM all the layout and the calibre(DRC&LVS)
all the layout are drew in manual and as you can see in the report, the overall arrangement looks really good

also including all of the test case, conclusion, time period, average current and power calculation
all of the snapshots are include in the phase3 report.

conclusion:
area: 16.065 * 51.295
Power = 13.1881uA * 1.8V = 23.73858 uW 
Minimum time period: 0.234ns

project files:
demo0.zip contains all the modules I used, schematic layout and the library content shows on the top of the report. 