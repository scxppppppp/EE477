Haoda Wang haodawan@usc.edu  USCid  8497309773
Jason Yik  jyik@usc.edu      USCid  6321385779
Wufei      wufei@usc.edu     USCid  6897429283

We have done all the required parts of the project phase1 successfully
including all of the schematic design, test model, test and the delay calculation.....
all of the snapshots are include in the phase1 report.
project files:
MUL.zip contains the multiplier design and divider.tar.xz contains the divider design 