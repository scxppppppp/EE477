Haoda Wang haodawan@usc.edu  USCid  8497309773  section3 
Jason Yik  jyik@usc.edu      USCid  6321385779  section2.1
Wufei      wufei@usc.edu     USCid  6897429283  section2.2

We have done all the required parts of the project phase2 successfully
including all of the schematic design, test model, test and the timing calculation.....
all of the snapshots are include in the phase2 report.

project files:
demo0.zip contains all the modules we used and the cells with the prefix project would be the design of the phase2. 