Wufei wufei@usc.edu   USCid 6897429283
I have done all the required parts of the Lab2, including all of the schematic design, layout design, test
and the delay calculation.....
all of the snapshots are include in the lab2 report.