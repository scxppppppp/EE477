Fei Wu
the word file in the folder contains all of the screenshots of the lab1.
I have done all of parts required, except the final process, combining each gate to a DUT made by Layout.
Some of the ideas to make the layout refer the standard units and the TA's videos and discussions.